<?php

	class Kelas extends CI_Controller{

		public function index(){
			$data ['title'] = "Data Kelas";
			$data ['kelas'] =$this->sppmodel->get_data('kelas')->result();
			$this->load->view('admin/kelas', $data);
		}

		public function tambah(){
			$data ['title'] = "Tambah Data Kelas";
			$this->load->view('admin/tambahkelas ', $data);
		}
		public function tambah_aksi()
		{
			$this->_rules();

			if($this->form_validation->run()== FALSE) {
				$this->tambah();
			}else{
				$nama_kelas = $this->input->post('nama_kelas');
				$id_kk = $this->input->post('id_kk');

				$data = array(
						'nama_kelas' =>$nama_kelas,
						'id_kk' => $id_kk,
				);

				$this->sppmodel->insert_data($data, 'kelas');
				$this->session->set_flashdata('pesan','<div class="alert alert-success alert-dismissible fade show" role="alert">
				  <strong>Data berhasil ditambahkan!
				  </strong> You should check in on some of those fields below.
				  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
				</div>');
				redirect('Kelas');
			}
		}

		public function _rules(){

			$this->form_validation->set_rules('nama_kelas', 'nama_kelas', 'required');
			$this->form_validation->set_rules('id_kk', 'id_kk', 'required');
		}
	}

 ?>