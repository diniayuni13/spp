<?php

	class Kelas extends CI_Controller{

		public function index(){
			$data ['title'] = "Data Kelas";
			$data ['kelas'] =$this->sppmodel->get_data('kelas')->result();
			$this->load->view('admin/kelas', $data);
		}

		public function tambah(){
			$data ['title'] = "Tambah Data Kelas";
			$this->load->view('admin/tambahkelas ', $data);
		}
	}

 ?>