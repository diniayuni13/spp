<?php

	/**
	 * 
	 */
	class Dashboard extends CI_Controller
	{
		
		public function index ()
		{
			$data['title'] = "Dashboard";
			$siswa = $this->db->query("SELECT * FROM siswa");
			$pembayaran = $this->db->query("SELECT * FROM pembayaran");
			$data['siswa'] = $siswa->num_rows();
			$data['pembayaran'] = $pembayaran->num_rows();

			$this->load->view('admin/dashboard', $data);
		}
	}

 ?>