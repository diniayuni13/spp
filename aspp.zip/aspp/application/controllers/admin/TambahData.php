<?php

	/**
	 * 
	 */
	class Tambahdata extends CI_Controller
	{
		
		public function index ()
		{
			$data['title'] = "Tambah data";
			$data ['kelas'] =$this->sppmodel->get_data('kelas')->result();
			$this->load->view('admin/tambahdata', $data);
		}
	}



 ?>